﻿---
title: Exercício prático
layout: default
---

### UnB - Universidade de Brasilia
### FGA - Faculdade do Gama
### OO - Orientação por objetos
------

Atividade para realizar em dupla e entregar via GitHub. Uma entrega por dupla.
Prazo para entrega: 4/4/2017, 23:59:59.

**Questão 1:** Os termos abaixo estão relacionados ao paradigma de *Orientação por Objetos*. Defina cada um dos termos com base no livro-texto (Eck, David J. Introduction to Programming Using Java, 6th ed. 2011).
* classe
* objeto
* elementos de classe
* atributos
* métodos
* método construtor padrão
* método construtor alternativo
* estado de um objeto
* retenção de estado



Classe: Uma classe é o agrupamento de objetos com a mesma estrutura de dados, definida
 pelos atributos ou características e pelos métodos ou comportamentos, ou seja, classe é a descrição do objeto.



Objeto: Objeto é uma classe sendo estanciada. De maneira mais conceitual, um objeto é algo único
que contém atributos e possui um comportamento. Cada objeto tem uma identidade e é distinguível de outro mesmo que seus 
atributos sejam idênticos.

Elementos de uma classe: Uma classe contém atributos e métodos.



Atributos: Atributos são o conjunto de características de uma classe. São definidos por algum tipo de dado que receberá um determinado valor 
posteriormente.



Métodos: Métodos são o conjunto de funcionalidades da classe. Para cada método, especifica-se sua assinatura, composta por: 
Nome, tipo, lista de argumentos e visibilidade.



Método construtor padrão: O Método construtor padrão é aquele que não recebe nenhum parâmetro.
Em termos mais simples, é aquele que não recebe nenhuma informação. Ele será sempre executado quando um objeto for criado.



Método construtor alternativo: O Método construtor alternativo é aquele que recebe parâmetros previamente.



Estado de um objeto: Estado de um objeto é o conjunto de valores que os atributos recebem em um dado momento, podendo ser alterado a 
partir de seus métodos.



Retenção de estado: Retenção de estado é a capacidade que um objeto tem de manter seu estado inicial, ou seja, os valores dos seus 
atributos até a próxima alteração.







**Questão 2:** Julgue as seguintes frases como verdadeiras ou falsas e explique o motivo delas estarem certas ou erradas. Nos casos em que julgar uma sentença como errada, altere-a de modo a corrigi-la.

a) Dois objetos instanciados através do método construtor padrão terão o mesmo estado e, portanto, suas referências serão iguais. 

b) Uma classe pode ter apenas um método construtor alternativo para instanciação de seus objetos. 

c) Retenção de estados é uma propriedade do paradigma OO que permite aos objetos manterem os valores de seus atributos até o momento em que um estímulo externo ao objeto solicite uma alteração no valor de algum atributo.

d) Em Java, o operador . (ponto) serve para acessar somente os métodos de um objeto. 

e) Métodos destrutores são aqueles métodos que são chamados explicitamente pelo algoritmo para destruir objetos e liberar os espaços que eles ocupam em memória. Em Java métodos destrutores são implementos com o nome **finalize()** e definidos em cada classe.



a) Dois objetos instanciados através do método construtor padrão terão o mesmo estado e, portanto, suas referências serão iguais.


Errado. Dois objetos instanciados através do método construtor padrão poderão ter o mesmo estado, porém, suas referências serão 
distintas. a) Dois objetos instanciados através do método construtor padrão poderão ter o mesmo estado, porém, suas referências 
serão distintas



b) Uma classe pode ter apenas um método construtor alternativo para instanciação de seus objetos.


Errado. Se for utilizado mais de um construtor, o Java será inteligente o suficiente para saber qual método utilizar dependendo dos
parâmetros que forem passados. Porém, obviamente se forem criados dois construtores com a mesma lista de parâmetros, haverá problemas.
b) Uma classe pode ter mais de um método construtor alternativo para instanciação de seus objetos.



c) Retenção de estados é uma propriedade do paradigma OO que permite aos objetos manterem os valores de seus atributos até o momento em 
que um estímulo externo ao objeto solicite uma alteração no valor de algum atributo.


Correto. A retenção de estados permite que os objetos mantenham os valores de seus atributos até o momento em que estímulo externo ao
objeto (Método) solicite a alteração.



d) Em Java, o operador . (ponto) serve para acessar somente os métodos de um objeto.


Errado. O operador ponto serve para acessar atributos também. d) Em Java, o operador . (ponto) serve para acessar os atributos e métodos de
um objeto.



e) Métodos destrutores são aqueles métodos que são chamados explicitamente pelo algoritmo para destruir objetos e liberar os espaços que
eles ocupam em memória. Em Java métodos destrutores são implementos com o nome finalize() e definidos em cada classe.


Correto. O método finalize() especifica o que deve ser feito antes do espaço do objeto ser retomado pelo garbage collector.Este método 
é definido na classe Object como protected. Ao contrário do que acontece com construtores(onde o método correspondente na superclasse 
é automaticamente invocado), o método finalizador da superclasse deve ser invocado explicitamente (super.finalize()) ao final do corpo
do finalizador local.








**Questão 3:**  Considere o seguinte cenário:

*Um veículo aéreo não-tripulado (VANT, também conhecido como **drone** é todo e qualquer tipo de aeronave que não necessita de pilotos embarcados para ser guiada. Este tipo de aviões é controlado à distância por meios eletrônicos e computacionais, sob a supervisão de humanos, ou mesmo sem a sua intervenção, por meio de Controladores Lógicos Programáveis (CLP).* Fonte: [Wikipedia](https://pt.wikipedia.org/wiki/Ve%C3%ADculo_a%C3%A9reo_n%C3%A3o_tripulado)

Drones civis vendidos atualmente possuem, em sua maior parte, as seguintes características: 

| Característica   | Valores (intervalo)         |
|:-----------------|:----------------------------|
| N. de hélices    | 4, 6 ou 8                   |
| Câmera           | SD, HD, UHD ou s-UHD        |
| Vel. vert. max.  | de 10 a 16 m/s              |
| Vel. hor. max.   | de 10 a 16 m/s              |
| Autonomia bateria| de 5 a 30 minutos de voo    |
| Distância máxima | de 50 metros a 20 kilometros|

Além dessas características, drones possuem as seguintes funções básicas: a) aumentar/diminuir velocidade vertical, b) aumentar/diminuir velocidade horizontal, c) iniciar/interromper gravação da câmera e d) diminuir velocidades máxima (horizontal e vertical) em 50% sempre que a autonomia da bateria for menor do que 5 minutos. 

Dado esse cenário, pede-se aos alunos que representem (inicialmente) as características e comportamentos de um drone através de um diagrama de classes e, posteriormente, apresente a implementação dessa classe na linguagem Java. 



public class Drone {
	int N_de_hélices_max;
	int N_de_hélices_min;
	int N_de_hélices_med = 6;
	String Câmera;
	int Vel_vert_max;
	int Vel_vert_min;
	int Vel_hor_max;
	int Vel_hor_min;
	int Autonomia_bateria_max;
	int Autonomia_bateria_min;
	int Distância_max;
	int Distância_min;
	double Vel_vert_atual;
	double Vel_hor_atual;
	int Autonomia_atual;
	
	Drone() {
		N_de_hélices_max = 8;
		N_de_hélices_min = 4;
		N_de_hélices_med = 6;
		Câmera = "não definida";
		Vel_vert_max = 16;
		Vel_vert_min = 10;
		Vel_hor_max = 16;
		Vel_hor_min = 10;
		Autonomia_bateria_max = 30;
		Autonomia_bateria_min = 5;
		Distância_max = 20000;
		Distância_min = 50;
		}
	// Inicia gravação
    void iniciarGravação() {
        System.out.println("Gravação iniciada");
    }
    // Interrompe gravação
    void encerrarGravação() {
        System.out.println("Gravação encerrada");
    }
    //Acelera verticalmente
    void aceleraVerticalmente(double quantidade) {
        double velocidadeVerticalNova = this.Vel_vert_atual + quantidade;
        this.Vel_vert_atual = velocidadeVerticalNova;
    }
  //Acelera horizontalmente
    void aceleraHorizontalmente(double quantidade) {
        double velocidadeHorizontalNova = this.Vel_hor_atual + quantidade;
        this.Vel_hor_atual = velocidadeHorizontalNova;
    }
  //Desacelera verticalmente
    void desaceleraVerticalmente(double quantidade) {
        double velocidadeVerticalNova = this.Vel_vert_atual - quantidade;
        this.Vel_vert_atual = velocidadeVerticalNova;
    }
  //Desacelera horizontalmente
    void desaceleraHorizontalmente(double quantidade) {
        double velocidadeHorizontalNova = this.Vel_hor_atual - quantidade;
        this.Vel_hor_atual = velocidadeHorizontalNova;
    }
    /*diminui velocidades máxima (horizontal e vertical) em 50% sempre que a autonomia da 
     * bateria for menor do que 5 minutos
	 */
    void desaceleraHorizontal() {
    	if(Autonomia_atual < 5){
        double velocidadeHorizontalNova = this.Vel_hor_atual/2;
        this.Vel_hor_atual = velocidadeHorizontalNova;
    	}
    }
    	void desaceleraVertical() {
        	if(Autonomia_atual < 5){
            double velocidadeVerticalNova = this.Vel_vert_atual/2;
            this.Vel_vert_atual = velocidadeVerticalNova;
        	}
    }
	public static void main(String[] args) {
		

	}

}



**Questão 4:** Considerando a classe definida e implementada na questão 5, pede-se que os seguintes objetos sejam criados a partir do programa principal: 

| Característica   | drone1         | drone2         | drone3            | drone4            |
|:-----------------|:---------------|:---------------|:------------------|:------------------|
| Marca            | Hubsan         | Hubsan         | DJI               | DJI               |
| Modelo           | X4 mini        | H501S X4 FPV   | Mavic Pro         | Spreading Wings   |
| N. de hélices    | 4              | 4              | 4                 | 8                 |
| Câmera           | SD             | HD             | UHD               | SUHD              |
| Vel. vert. max.  | 10 m/s         | 12 m/s         | 16 m/s            | 16 m/s            |
| Vel. hor. max.   | 10 m/s         | 12 m/s         | 16 m/s            | 16 m/s            |
| Autonomia bateria| 7 minutos      | 20 minutos     | 27 minutos        | 15 minutos        |
| Distância máxima | até 150 metros | até 1 kilometro| até 13 kilometros | até 13 kilometros |



public class Drone {

	String marca;
 
	String modelo;
 
	int N_de_hélices;
 
	String câmera;
 
        int Vel_vert_max;

	int Vel_hor_max;
 
        int Autonomia_bateria;
  
        int Distância_máxima;

	


	Bicicleta(String mar, String mod, , int a, String cam, int b, int c, int d, int e) {

		marca = mar;

		modelo = mod;

	        N_de_hélices = a;

	        câmera = cam;

                Vel_vert_max = b;

	        Vel_hor_max = c;
 
                Autonomia_bateria = d;
 
                Distância_máxima = e;

	}
	

        public static void main (String[] args) {

		Drone drone1,

                      drone2,
 
                      drone3,

                      drone4;


		drone1 = new Drone("Hubsan", "X4 mini", 4, "SD", 10, 10, 7, 150);

		drone2 = new Drone("Hubsan", "H501S X4 FPV", 4, "HD", 12, 12, 20, 1000;

		drone3 = new Drone("DJI", "Mavic Pro", 4, "UHD", 16, 16, 27, 13000);

                drone4 = new Drone("DJI", "Spreading Wings", 8, "SUHD", 16, 16, 15, 13000);
        }

}



**Questão 5:** Ainda levando em consideração o cenário descrito nas questões 3 e 4, é necessário fazer com que os comandos realizados pelo usuário no controle remoto sejam enviados ao drone. Para isso, é necessário que o controle remoto estabeleça uma conexão com o drone. A partir desse momento é possível enviar os seguintes comandos ao drone: a) aumentar ou diminuir a velocidade vertical em passos de 1 m/s; b) aumentar ou diminuir a velocidade horizontal em passos de 1m/s e, c) ativar ou desativar a câmera. É importante ressaltar que um controle remoto só pode estar conectado a um drone apenas. Por fim, controles remotos possuem baterias com autonomia entre 60 e 90 minutos e alcance entre 20 metros e 20 kilometros.  

Desse modo, pede-se nessa questão que seja modelada e implementada em Java a classe que representa as características e o comportamento de um controle remoto, de modo que o drone possa ser comandado a partir do comandos enviados pelo controle remoto.


**Questão 6:** Sejam os seguintes códigos da *ClasseA* e da aplicação principal escritas em JAVA. 

Questao6.java
{% highlight java %}
public class Questao6 {
  int   a1; 
  float   a2; 
  String  a3;
  boolean a4;
  
  public Questao6() {}
  
  public Questao6(int a, float b, String c, boolean d){
    a1 = a;
    a2 = b;
    a3 = c;
    a4 = d;
  }
}
{% endhighlight%}

Principal.java
{% highlight java%}
public class Principal {
  public static void main (String[] args) {
    Questao6 q1, 
             q2,
             q3;
    
    q1 = new Questao6();
    q2 = new Questao6(0, 0.0f, null, false);
    q3 = new Questao6(1, 1.0f, "null", false);
    
    //---> local onde a instrução do item c) será inserida.
  }
}
{% endhighlight %}
Responda as seguintes questões com base nos códigos acima: 

a) As referências a1 e a2 para objetos de *ClasseA* são iguais?

b) Qual o estado de cada dos objetos de cada referência? 

c) O que será impresso pela função *main* da classe *Principal* se a linha número *11* for igual a: 
{% highlight java%}
System.out.println(q1 == q2);
System.out.println(q1.a1 == q2.a1);
System.out.println(q2.a3 == q3.a3);
System.out.println(q1.a2 == q2.a2);
System.out.println(q1.a4 == q3.a4);
System.out.println(q3 == q2);
{% endhighlight %}



a) Não, as referências a1 e a2 para objetos de ClasseA não são iguais. a1 é int e a2 é float.



b) q1.a1=0;

q1.a2=0.0f;

q1.a3=null;

q1.a4=false;


q2.a1=0;

q2.a2=0.0f;

q2.a3=null;

q2.a4=false;


q3.a1=1;

q3.a2=1.0f;

q3.a3="null";

q3.a4=false;


c) Respectivamente:
 
                   False

                    True
  
                    True
        
                    True
         
                    True
        
                    False




**Questão 7:**


**Questão 8:**


**Questão 9:**


**Questão 10:**


## Referências:
\[[OPEN ACCESS][eckDavid]\] Eck, David J. Introduction to Programming Using Java, 6th ed. 2011



---
*Última modificação: 3 de abril de 2017, 22:52.*





[eckDavid]: http://math.hws.edu/javanotes/
