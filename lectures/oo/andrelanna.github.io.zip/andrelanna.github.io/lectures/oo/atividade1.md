---
title: Atividade 1
layout: default
---

### UnB - Universidade de Brasilia
### FGA - Faculdade do Gama
### OO - Orientação por objetos
------

Atividade para realizar em sala de aula. 
(Não é necessário entregar)


1. O que é uma classe? O que é um objeto? Qual a relação entre esses dois elementos?

2. O que são atributos de uma classe? Para que eles servem?

3. O que são métodos de uma classe? 

4. O que é o estado de um objeto?



Considere a FGA como referência para o seguinte cenário: 

Um professor deseja criar um cadastro dos alunos de suas turmas. Para tal cadastro ele considerou necessárias as seguintes informações para suas turmas e seus alunos: 

* Turma: 
  - código da turma
  - nome da disciplina
  - código da disciplina
  - total de vagas da turma
  - quantidade de vagas ocupadas
  - quantidade de vagas livres

* Aluno: 
  - matrícula
  - nome 
  - email

Sabe-se que o professor possui as seguintes turmas: 
  - turma B de Orientação por objetos (cod. 25), com capacidade de 45 alunos, sendo que 35 estão nesse momento matriculados na disciplina; 
  - Turma A de Desenvolvimento Avançado de Software (cod. 13), com capacidade de 30 alunos e atualmente 30 alunos matriculados.

